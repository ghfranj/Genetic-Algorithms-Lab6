package lab5;

import org.uncommons.watchmaker.framework.EvolutionaryOperator;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MyMutation implements EvolutionaryOperator<double[]> {

    private double mutationProbability;

    public MyMutation(double mutationProbability) {
        this.mutationProbability = mutationProbability;
    }

    public List<double[]> apply(List<double[]> population, Random random) {
        List<double[]> mutatedPopulation = new ArrayList<>();
        for (double[] candidate : population) {
            double[] mutatedCandidate = candidate.clone();
            for (int i = 0; i < mutatedCandidate.length; i++) {
                if (random.nextDouble() < mutationProbability) {
                    // Mutate the gene by adding a small random value.
                    mutatedCandidate[i] += random.nextGaussian(); // Using Gaussian mutation for simplicity.
                }
            }
            mutatedPopulation.add(mutatedCandidate);
        }
        return mutatedPopulation;
    }
}
