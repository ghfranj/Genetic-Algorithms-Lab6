package lab5;

import org.uncommons.watchmaker.framework.operators.AbstractCrossover;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MyCrossover extends AbstractCrossover<double[]> {

    public MyCrossover() {
        super(1); // We'll generate one child per mating.
    }

    protected List<double[]> mate(double[] parent1, double[] parent2, int numberOfCrossoverPoints, Random random) {
        double[] child1 = parent1.clone();
        double[] child2 = parent2.clone();

        // Choose a random crossover point.
        int crossoverPoint = random.nextInt(parent1.length);

        // Swap the genes beyond the crossover point.
        for (int i = crossoverPoint; i < parent1.length; i++) {
            double temp = child1[i];
            child1[i] = child2[i];
            child2[i] = temp;
        }

        // Return the children.
        List<double[]> children = new ArrayList<>();
        children.add(child1);
        children.add(child2);
        return children;
    }
}
